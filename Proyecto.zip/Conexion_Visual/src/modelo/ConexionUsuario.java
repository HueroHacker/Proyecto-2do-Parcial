
package modelo;

import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;
import java.sql.SQLException;
public class ConexionUsuario {
    private final String base= "usuarios";
    private final String user= "root";
    private final String password= "";
    private final String url= "jdbc:mysql://localhost:3306/"+base;
    private Connection con=null;
    public Connection getConexion(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url,user,password);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(ConexionUsuario.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ConexionUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
}
