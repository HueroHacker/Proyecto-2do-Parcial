package Conex;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;


public class Conexion_Visual {
 Connection con;
 public Conexion_Visual(){

try{
    Class.forName("com.mysql.cj.jdbc.Driver");
    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/usuarios","root",""); 
} catch (Exception e){
    System.err.println("Error:" + e);
}
    
 }
 public static void main(String[]args){
     Conexion_Visual cn=new Conexion_Visual();
     
     Statement st;
     ResultSet rs;
     
     try{
         st=cn.con.createStatement();
         rs=st.executeQuery("Select * from aspirantes");
         while (rs.next()){
             System.out.println(rs.getInt("idAspirantes")+ " " +rs.getString("Nombres")+ " " +rs.getString("Apellido Paterno")+ " " +rs.getInt("Apellido Materno")+ " " +rs.getString("Edad"));
         }
             
         cn.con.close();
     
     }catch (Exception e){
     
     
 }
 }
}